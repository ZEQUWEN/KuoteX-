"""Состояние сессии MTProto: msg_id, seq_no, salt, окно анти-replay."""
from __future__ import annotations

import os
import struct
import threading
import time

from .crypto import Message, MTProtoSecurityError, decrypt_message, encrypt_message

# Допустимое расхождение времени (сек): сообщения вне окна отбрасываются.
PAST_WINDOW = 300
FUTURE_WINDOW = 30


class Session:
    def __init__(self, auth_key: bytes, *, is_client: bool = True, salt: int = 0):
        if len(auth_key) != 256:
            raise MTProtoSecurityError("auth_key must be 256 bytes")
        self.auth_key = auth_key
        self.is_client = is_client
        self.salt = salt
        self.session_id = struct.unpack("<q", os.urandom(8))[0]
        self._seq = 0
        self._last_msg_id = 0
        self._seen: set[int] = set()
        self._time_offset = 0.0
        self._lock = threading.Lock()

    # --- время / идентификаторы ---
    def _now(self) -> float:
        return time.time() + self._time_offset

    def sync_time(self, server_msg_id: int) -> None:
        """Коррекция часов по msg_id сервера (bad_msg_notification 16/17)."""
        self._time_offset = (server_msg_id >> 32) - time.time()

    def next_msg_id(self) -> int:
        with self._lock:
            now = self._now()
            mid = (int(now) << 32) | ((int((now % 1) * (1 << 30)) << 2) & 0xFFFFFFFC)
            mid |= 0 if self.is_client else 1  # клиент: чётные, сервер: нечётные
            if mid <= self._last_msg_id:
                mid = self._last_msg_id + 4
            self._last_msg_id = mid
            return mid

    def next_seq_no(self, content_related: bool = True) -> int:
        with self._lock:
            if content_related:
                self._seq += 1
                return self._seq * 2 - 1
            return self._seq * 2

    # --- ввод/вывод ---
    def encrypt(self, body: bytes, content_related: bool = True) -> bytes:
        msg = Message(
            salt=self.salt,
            session_id=self.session_id,
            msg_id=self.next_msg_id(),
            seq_no=self.next_seq_no(content_related),
            body=body,
        )
        return encrypt_message(self.auth_key, msg, from_client=self.is_client)

    def decrypt(self, data: bytes) -> Message:
        msg = decrypt_message(
            self.auth_key,
            data,
            from_client=not self.is_client,
            expected_session_id=self.session_id,
        )
        self._validate(msg)
        return msg

    def _validate(self, msg: Message) -> None:
        # 1) чётность msg_id входящего должна быть противоположна нашей
        expect_odd = 1 if self.is_client else 0
        if msg.msg_id % 2 != expect_odd:
            raise MTProtoSecurityError("bad msg_id parity")
        # 2) временное окно
        ts = msg.msg_id >> 32
        now = self._now()
        if ts < now - PAST_WINDOW or ts > now + FUTURE_WINDOW:
            raise MTProtoSecurityError("msg_id outside acceptance window")
        # 3) анти-replay
        with self._lock:
            if msg.msg_id in self._seen:
                raise MTProtoSecurityError("replayed msg_id")
            self._seen.add(msg.msg_id)
            if len(self._seen) > 4096:
                cutoff = int(now - PAST_WINDOW) << 32
                self._seen = {m for m in self._seen if m >= cutoff}
