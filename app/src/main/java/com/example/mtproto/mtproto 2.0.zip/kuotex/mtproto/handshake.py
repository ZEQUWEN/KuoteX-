"""Diffie–Hellman handshake: получение auth_key (2048 бит).

Здесь реализованы криптографические проверки и вычисления.
Обмен пакетами (req_pq_multi / req_DH_params / set_client_DH_params)
делегируется транспорту KuoteX — модуль намеренно не зависит от сети,
что позволяет тестировать его детерминированно.
"""
from __future__ import annotations

import hashlib
import os

from .crypto import MTProtoSecurityError, sha1

# Стандартная безопасная группа MTProto (g=3, 2048-битный p)
DH_P = int(
    "C71CAEB9C6B1C9048E6C522F70F13F73980D40238E3E21C14934D037563D930F"
    "48198A0AA7C14058229493D22530F4DBFA336F6E0AC925139543AED44CCE7C37"
    "20FD51F69458705AC68CD4FE6B6B13ABDC9746512969328454F18FAF8C595F64"
    "2477FE96BB2A941D5BCD1D4AC8CC49880708FA9B378E3C4F3A9060BEE67CF9A4"
    "A4A695811051907E162753B56B0F6B410DBA74D8A84B2A14B3144E0EF1284754"
    "FD17ED950D5965B4B9DD46582DB1178D169C6BC465B0D6FF9CA3928FEF5B9AE4"
    "E418FC15E83EBEA0F87FA9FF5EED70050DED2849F47BF959D956850CE929851F"
    "0D8115F635B105EE2E4E15D04B2454BF6F4FADF034B10403119CD8E3B92FCC5B",
    16,
)
DH_G = 3
_MIN = 2 ** (2048 - 64)


def _is_safe_prime(p: int, g: int) -> bool:
    """p — безопасное простое (p и q=(p-1)/2 простые), g порождает подгруппу
    порядка q. Это строже, чем табличная проверка `p mod 24 == 23`, и не зависит
    от конкретного значения p, присланного сервером."""
    if p.bit_length() != 2048:
        return False
    if g not in (2, 3, 4, 5, 6, 7):
        return False
    q = (p - 1) // 2
    if p % 2 == 0 or not _mr(p) or not _mr(q):
        return False
    # g не должен быть 1, p-1 и обязан лежать в подгруппе порядка q
    if not (1 < g < p - 1):
        return False
    return pow(g, q, p) == 1


def _mr(n: int, rounds: int = 32) -> bool:
    if n < 2:
        return False
    for sp in (2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37):
        if n % sp == 0:
            return n == sp
    d, r = n - 1, 0
    while d % 2 == 0:
        d //= 2
        r += 1
    for _ in range(rounds):
        a = 2 + int.from_bytes(os.urandom(32), "big") % (n - 4)
        x = pow(a, d, n)
        if x in (1, n - 1):
            continue
        for _ in range(r - 1):
            x = x * x % n
            if x == n - 1:
                break
        else:
            return False
    return True


def check_dh_param(value: int, p: int) -> None:
    """1 < value < p-1 и защита от малых/крайних значений (Telegram security guidelines)."""
    if not (1 < value < p - 1):
        raise MTProtoSecurityError("DH value out of range")
    if not (_MIN < value < p - _MIN):
        raise MTProtoSecurityError("DH value too close to boundary")


def gen_b(p: int = DH_P) -> int:
    while True:
        b = int.from_bytes(os.urandom(256), "big")
        if 1 < b < p - 1:
            return b


def derive_auth_key(g_a: int, b: int, p: int = DH_P, g: int = DH_G,
                    verify_prime: bool = True) -> tuple[bytes, bytes, int]:
    """-> (auth_key[256], auth_key_aux_hash[8], g_b)."""
    if verify_prime and not _is_safe_prime(p, g):
        raise MTProtoSecurityError("server DH group is not a safe prime group")
    check_dh_param(g_a, p)
    g_b = pow(g, b, p)
    check_dh_param(g_b, p)
    key_int = pow(g_a, b, p)
    auth_key = key_int.to_bytes(256, "big")
    aux = sha1(auth_key)[:8]
    return auth_key, aux, g_b


def new_nonce_hash(new_nonce: bytes, num: int, auth_key: bytes) -> bytes:
    aux = sha1(auth_key)[:8]
    return hashlib.sha1(new_nonce + bytes([num]) + aux).digest()[-16:]
