"""KDF и обёртка сообщений MTProto 2.0 для KuoteX."""
from __future__ import annotations

import hashlib
import hmac
import os
import struct
from dataclasses import dataclass

from .ige import ige_decrypt, ige_encrypt


class MTProtoSecurityError(Exception):
    """Нарушение криптографического инварианта — соединение обязано умереть."""


def sha256(*parts: bytes) -> bytes:
    h = hashlib.sha256()
    for p in parts:
        h.update(p)
    return h.digest()


def sha1(data: bytes) -> bytes:
    return hashlib.sha1(data).digest()


def auth_key_id(auth_key: bytes) -> bytes:
    """Младшие 8 байт SHA1(auth_key)."""
    return sha1(auth_key)[-8:]


def msg_key_large(auth_key: bytes, payload: bytes, from_client: bool) -> bytes:
    x = 0 if from_client else 8
    return sha256(auth_key[88 + x:88 + x + 32], payload)


def msg_key_of(auth_key: bytes, payload: bytes, from_client: bool) -> bytes:
    return msg_key_large(auth_key, payload, from_client)[8:24]


def kdf(auth_key: bytes, msg_key: bytes, from_client: bool) -> tuple[bytes, bytes]:
    """MTProto 2.0 KDF -> (aes_key, aes_iv)."""
    if len(auth_key) != 256:
        raise MTProtoSecurityError("auth_key must be 2048-bit (256 bytes)")
    x = 0 if from_client else 8
    sha_a = sha256(msg_key, auth_key[x:x + 36])
    sha_b = sha256(auth_key[40 + x:40 + x + 36], msg_key)
    aes_key = sha_a[0:8] + sha_b[8:24] + sha_a[24:32]
    aes_iv = sha_b[0:8] + sha_a[8:24] + sha_b[24:32]
    return aes_key, aes_iv


def _padding(length: int) -> bytes:
    # 12..1024 случайных байт так, чтобы итог был кратен 16
    pad = 12 + (-(length + 12) % 16)
    if pad < 12:
        pad += 16
    return os.urandom(pad)


@dataclass(slots=True)
class Message:
    salt: int
    session_id: int
    msg_id: int
    seq_no: int
    body: bytes


def encrypt_message(auth_key: bytes, msg: Message, from_client: bool = True) -> bytes:
    inner = struct.pack(
        "<qqqii", msg.salt, msg.session_id, msg.msg_id, msg.seq_no, len(msg.body)
    ) + msg.body
    inner += _padding(len(inner))
    mk = msg_key_of(auth_key, inner, from_client)
    key, iv = kdf(auth_key, mk, from_client)
    return auth_key_id(auth_key) + mk + ige_encrypt(inner, key, iv)


def decrypt_message(
    auth_key: bytes,
    data: bytes,
    from_client: bool = False,
    expected_session_id: int | None = None,
) -> Message:
    if len(data) < 24 + 16 or (len(data) - 24) % 16:
        raise MTProtoSecurityError("bad envelope length")
    if not hmac.compare_digest(data[:8], auth_key_id(auth_key)):
        raise MTProtoSecurityError("unknown auth_key_id")
    mk = data[8:24]
    key, iv = kdf(auth_key, mk, from_client)
    inner = ige_decrypt(data[24:], key, iv)
    # обязательная проверка msg_key ДО парсинга (защита от oracle-атак)
    if not hmac.compare_digest(mk, msg_key_of(auth_key, inner, from_client)):
        raise MTProtoSecurityError("msg_key mismatch")
    salt, session_id, msg_id, seq_no, length = struct.unpack("<qqqii", inner[:32])
    if length < 0 or length % 4 or 32 + length > len(inner):
        raise MTProtoSecurityError("bad body length")
    if len(inner) - 32 - length < 12:
        raise MTProtoSecurityError("padding too short")
    if expected_session_id is not None and session_id != expected_session_id:
        raise MTProtoSecurityError("session_id mismatch")
    return Message(salt, session_id, msg_id, seq_no, inner[32:32 + length])
