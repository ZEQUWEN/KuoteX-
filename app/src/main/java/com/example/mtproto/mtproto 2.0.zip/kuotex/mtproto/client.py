"""Слой интеграции с архитектурой KuoteX.

MTProtoChannel — единственная точка, которую видит остальной мессенджер.
Он умышленно узкий: send(bytes) / receive() -> bytes. Сериализация
(TL / protobuf / json — что используется в KuoteX) остаётся снаружи.

Подключение к существующей архитектуре:

    from kuotex.mtproto import MTProtoChannel, KeyStore

    channel = MTProtoChannel(auth_key=store.load(dc_id), host=..., port=...)
    await channel.start()
    await channel.send(codec.encode(update))
    raw = await channel.receive()
"""
from __future__ import annotations

import asyncio
import contextlib
import logging
import os
from typing import Awaitable, Callable

from .crypto import MTProtoSecurityError
from .session import Session
from .transport import ObfuscatedTransport

log = logging.getLogger("kuotex.mtproto")


class KeyStore:
    """Минимальное хранилище auth_key. В KuoteX замени на свой secure storage
    (Keychain / KeyStore / libsecret). Файлы пишутся с правами 0600."""

    def __init__(self, path: str = "~/.kuotex/keys"):
        self.path = os.path.expanduser(path)
        os.makedirs(self.path, mode=0o700, exist_ok=True)

    def _f(self, dc_id: int) -> str:
        return os.path.join(self.path, f"dc{dc_id}.key")

    def load(self, dc_id: int) -> bytes | None:
        try:
            with open(self._f(dc_id), "rb") as fh:
                data = fh.read()
            return data if len(data) == 256 else None
        except FileNotFoundError:
            return None

    def save(self, dc_id: int, auth_key: bytes) -> None:
        fd = os.open(self._f(dc_id), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "wb") as fh:
            fh.write(auth_key)

    def wipe(self, dc_id: int) -> None:
        with contextlib.suppress(FileNotFoundError):
            os.remove(self._f(dc_id))


class MTProtoChannel:
    def __init__(
        self,
        auth_key: bytes,
        host: str,
        port: int,
        dc_id: int = 2,
        *,
        is_client: bool = True,
        on_message: Callable[[bytes], Awaitable[None]] | None = None,
        socket_factory: Callable[[], Awaitable] | None = None,  # для Tor/SOCKS5
    ):
        self.session = Session(auth_key, is_client=is_client)
        self.transport = ObfuscatedTransport(host, port, dc_id)
        self.on_message = on_message
        self.socket_factory = socket_factory
        self.inbox: asyncio.Queue[bytes] = asyncio.Queue()
        self._task: asyncio.Task | None = None
        self._closed = False

    async def start(self) -> None:
        sock = await self.socket_factory() if self.socket_factory else None
        await self.transport.connect(sock=sock)
        self._task = asyncio.create_task(self._pump(), name="mtproto-reader")

    async def send(self, body: bytes, content_related: bool = True) -> None:
        await self.transport.send(self.session.encrypt(body, content_related))

    async def receive(self) -> bytes:
        return await self.inbox.get()

    async def _pump(self) -> None:
        backoff = 0.5
        while not self._closed:
            try:
                raw = await self.transport.recv()
                if len(raw) == 4:  # транспортная ошибка вида -404
                    code = int.from_bytes(raw, "little", signed=True)
                    raise MTProtoSecurityError(f"transport error {code}")
                msg = self.session.decrypt(raw)
                if self.on_message:
                    await self.on_message(msg.body)
                else:
                    await self.inbox.put(msg.body)
                backoff = 0.5
            except MTProtoSecurityError as e:
                # Безопасность важнее доступности: рвём соединение, не логируем данные.
                log.error("security violation: %s — dropping connection", e)
                await self.transport.close()
                if self._closed:
                    return
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 30)
                with contextlib.suppress(Exception):
                    await self.transport.connect()
            except (asyncio.IncompleteReadError, ConnectionError, OSError):
                if self._closed:
                    return
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 30)
                with contextlib.suppress(Exception):
                    await self.transport.connect()

    async def close(self) -> None:
        self._closed = True
        if self._task:
            self._task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._task
        await self.transport.close()
