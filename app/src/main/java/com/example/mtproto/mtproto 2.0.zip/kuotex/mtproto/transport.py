"""Транспорт: abridged framing + obfuscated2 (анти-DPI, важно для анонимности).

Обфускация делает поток неотличимым от случайного: нет фиксированных
заголовков, длина не выдаёт границы TLS-записей, первый пакет —
64 случайных байта, задающих CTR-ключи в обе стороны.
"""
from __future__ import annotations

import asyncio
import os
import struct

from .ige import AesCtr

_BAD_FIRST = {b"HEAD", b"POST", b"GET ", b"OPTI", bytes.fromhex("eeeeeeee"),
              bytes.fromhex("dddddddd"), b"\x16\x03\x01\x02"}
ABRIDGED = b"\xef\xef\xef\xef"


def make_obfuscation(protocol: bytes = ABRIDGED, dc_id: int = 0):
    """-> (init_payload_64, encryptor, decryptor)"""
    while True:
        buf = bytearray(os.urandom(64))
        if buf[0] == 0xEF:
            continue
        if bytes(buf[:4]) in _BAD_FIRST:
            continue
        if buf[4:8] == b"\x00\x00\x00\x00":
            continue
        break
    buf[56:60] = protocol
    struct.pack_into("<h", buf, 60, dc_id)

    enc_key, enc_iv = bytes(buf[8:40]), bytes(buf[40:56])
    rev = bytes(buf[8:56][::-1])
    dec_key, dec_iv = rev[:32], rev[32:48]

    encryptor = AesCtr(enc_key, enc_iv)
    decryptor = AesCtr(dec_key, dec_iv)
    init = bytes(buf[:56]) + encryptor(bytes(buf))[56:64]
    return init, encryptor, decryptor


def frame(payload: bytes) -> bytes:
    """abridged framing (длина в 4-байтных словах)."""
    if len(payload) % 4:
        raise ValueError("payload must be 4-byte aligned")
    n = len(payload) // 4
    if n < 0x7F:
        return bytes([n]) + payload
    return b"\x7f" + n.to_bytes(3, "little") + payload


class ObfuscatedTransport:
    """Асинхронный клиент поверх TCP (или поверх SOCKS5/Tor — см. proxy)."""

    def __init__(self, host: str, port: int, dc_id: int = 0):
        self.host, self.port, self.dc_id = host, port, dc_id
        self._r: asyncio.StreamReader | None = None
        self._w: asyncio.StreamWriter | None = None

    async def connect(self, *, sock=None) -> None:
        self._r, self._w = await asyncio.open_connection(
            None if sock else self.host, None if sock else self.port, sock=sock
        )
        init, self._enc, self._dec = make_obfuscation(ABRIDGED, self.dc_id)
        self._w.write(init)
        await self._w.drain()

    async def send(self, payload: bytes) -> None:
        self._w.write(self._enc(frame(payload)))
        await self._w.drain()

    async def recv(self) -> bytes:
        b = self._dec(await self._r.readexactly(1))[0]
        if b == 0x7F:
            b = int.from_bytes(self._dec(await self._r.readexactly(3)), "little")
        return self._dec(await self._r.readexactly(b * 4))

    async def close(self) -> None:
        if self._w:
            self._w.close()
            try:
                await self._w.wait_closed()
            except Exception:
                pass
