# MTProto 2.0 для KuoteX

Криптографический транспорт мессенджера: AES-256-IGE, KDF MTProto 2.0,
DH-handshake, обфусцированный TCP-транспорт (анти-DPI).

## Структура

| Файл | Назначение |
|---|---|
| `ige.py` | AES-256-IGE (encrypt/decrypt) + AES-CTR для обфускатора |
| `crypto.py` | `msg_key`, KDF, упаковка/распаковка зашифрованного сообщения |
| `session.py` | `msg_id`, `seq_no`, salt, окно приёма, анти-replay |
| `handshake.py` | DH: проверка группы, генерация `b`, вывод `auth_key` |
| `transport.py` | abridged framing + obfuscated2 |
| `client.py` | `MTProtoChannel` и `KeyStore` — точка стыковки с KuoteX |

## Быстрый старт

```python
from kuotex.mtproto import MTProtoChannel, KeyStore

store = KeyStore()
ch = MTProtoChannel(store.load(2), "149.154.167.51", 443, dc_id=2,
                    on_message=bus.emit)
await ch.start()
await ch.send(payload)          # payload — байты вашего TL/protobuf-кодека
```

## Точки интеграции с архитектурой KuoteX

1. **Хранилище ключей** — замените `KeyStore` на системный secure storage
   (Keychain / Android KeyStore / libsecret). Интерфейс: `load(dc_id)`,
   `save(dc_id, key)`, `wipe(dc_id)`.
2. **Сетевой слой** — `socket_factory` позволяет отдать готовый сокет
   (Tor/SOCKS5, WebSocket-бридж, ваш пул соединений). См.
   `examples/integrate_kuotex.py`.
3. **Шина событий** — `on_message: Callable[[bytes], Awaitable[None]]`
   вызывается на каждое валидное сообщение; без него сообщения копятся
   в `channel.inbox` (`await channel.receive()`).
4. **Сериализация** — модуль намеренно не знает о TL. Кодек KuoteX остаётся
   снаружи, что упрощает аудит криптослоя.

## Гарантии стабильности

* Автопереподключение с экспоненциальным backoff (0.5 → 30 с).
* Коррекция часов по `msg_id` сервера (`session.sync_time`) — лечит
  `bad_msg_notification 16/17` на устройствах с плывущим временем.
* Монотонные `msg_id` под блокировкой — безопасно при конкурентной отправке.
* Окно приёма ±(300/30) с + множество увиденных `msg_id` с автоочисткой.

## Гарантии анонимности

* **obfuscated2**: первый пакет — 64 случайных байта; далее весь поток —
  AES-CTR, статистически неотличим от случайного. Нет сигнатур для DPI.
* Рандомизированный паддинг 12…1024 байт — маскирует длину сообщений.
* `auth_key_id` — единственный постоянный идентификатор в потоке; при смене
  личности вызывайте `store.wipe(dc_id)` и переделывайте handshake.
* Транспорт принимает внешний сокет → тривиально заворачивается в Tor.
* Ошибки безопасности не попадают в логи вместе с данными: логируется только
  тип нарушения.

## Криптографические проверки (fail-closed)

Любое нарушение поднимает `MTProtoSecurityError` и рвёт соединение:

* `msg_key` проверяется **до** разбора тела (нет padding/parsing-oracle);
* сравнение `auth_key_id` и `msg_key` — constant-time (`hmac.compare_digest`);
* длина тела, минимальный паддинг (≥12), кратность 16;
* чётность `msg_id` (клиент — чётные, сервер — нечётные);
* `session_id` совпадает с текущим;
* DH: `p` — безопасное простое, `g` порождает подгруппу порядка `q`,
  `1 < g_a, g_b < p-1` и не ближе `2^1984` к границам.

## Тесты

```bash
python -m pytest tests -q     # 17 passed
```

Включён эталонный тест-вектор AES-IGE, проверки подделки шифротекста,
чужого `auth_key`, replay-атак и вырожденных DH-параметров.

## Что осталось сделать на стороне KuoteX

* Обмен пакетами handshake (`req_pq_multi` → `req_DH_params` →
  `set_client_DH_params`) через ваш TL-кодек — крипточасть готова в
  `handshake.py`.
* Обработка `new_session_created` / `bad_server_salt` → `session.salt = ...`.
* Контейнеры `msg_container` и подтверждения `msgs_ack` на уровне вашего
  роутера.
