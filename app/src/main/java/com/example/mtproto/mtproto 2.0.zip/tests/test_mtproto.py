import os
import struct
import pytest

from kuotex.mtproto import (ige_encrypt, ige_decrypt, Session, kdf,
                            encrypt_message, decrypt_message, Message,
                            MTProtoSecurityError, derive_auth_key, gen_b, DH_P,
                            make_obfuscation, frame)
from kuotex.mtproto.ige import IgeError


def test_ige_known_vector():
    # Тест-вектор AES-128-IGE (OpenSSL / Telegram docs)
    key = bytes.fromhex("000102030405060708090A0B0C0D0E0F")
    iv = bytes.fromhex("000102030405060708090A0B0C0D0E0F"
                       "101112131415161718191A1B1C1D1E1F")
    pt = bytes(32)
    ct = ige_encrypt(pt, key, iv)
    assert ct.hex() == ("1a8519a6557be652e9da8e43da4ef445"
                        "3cf456b4ca488aa383c79c98b34797cb")
    assert ige_decrypt(ct, key, iv) == pt


@pytest.mark.parametrize("n", [16, 32, 256, 1024])
def test_ige_roundtrip(n):
    key, iv, pt = os.urandom(32), os.urandom(32), os.urandom(n)
    assert ige_decrypt(ige_encrypt(pt, key, iv), key, iv) == pt


def test_ige_rejects_bad_sizes():
    with pytest.raises(IgeError):
        ige_encrypt(b"short", os.urandom(32), os.urandom(32))
    with pytest.raises(IgeError):
        ige_encrypt(os.urandom(16), os.urandom(32), os.urandom(16))


def test_kdf_direction_differs():
    ak, mk = os.urandom(256), os.urandom(16)
    assert kdf(ak, mk, True) != kdf(ak, mk, False)


def test_message_roundtrip_and_padding_randomness():
    ak = os.urandom(256)
    m = Message(1, 2, 0x600000000000000, 1, b"\x01\x02\x03\x04")
    a, b = encrypt_message(ak, m), encrypt_message(ak, m)
    assert a != b  # рандомизированный паддинг
    out = decrypt_message(ak, a, from_client=True)
    assert out.body == m.body and out.msg_id == m.msg_id


def test_tamper_detected():
    ak = os.urandom(256)
    data = bytearray(encrypt_message(ak, Message(1, 2, 3, 1, b"abcd")))
    data[40] ^= 1
    with pytest.raises(MTProtoSecurityError):
        decrypt_message(ak, bytes(data), from_client=True)


def test_wrong_auth_key():
    ak = os.urandom(256)
    data = encrypt_message(ak, Message(1, 2, 3, 1, b"abcd"))
    with pytest.raises(MTProtoSecurityError):
        decrypt_message(os.urandom(256), data, from_client=True)


def test_session_replay_and_parity():
    ak = os.urandom(256)
    client = Session(ak, is_client=True)
    server = Session(ak, is_client=False)
    server.session_id = client.session_id
    wire = client.encrypt(b"hello!!!")
    assert server.decrypt(wire).body == b"hello!!!"
    with pytest.raises(MTProtoSecurityError):  # replay
        server.decrypt(wire)


def test_session_seq_no():
    s = Session(os.urandom(256))
    assert s.next_seq_no(True) == 1
    assert s.next_seq_no(False) == 2
    assert s.next_seq_no(True) == 3


def test_msg_id_monotonic():
    s = Session(os.urandom(256))
    ids = [s.next_msg_id() for _ in range(500)]
    assert ids == sorted(ids) and len(set(ids)) == 500
    assert all(i % 4 == 0 for i in ids)


def test_dh_auth_key():
    b = gen_b()
    a = gen_b()
    g_a = pow(3, a, DH_P)
    ak, aux, g_b = derive_auth_key(g_a, b, verify_prime=True)
    assert len(ak) == 256 and len(aux) == 8
    assert ak == pow(g_b, a, DH_P).to_bytes(256, "big")


def test_dh_rejects_bad_g_a():
    with pytest.raises(MTProtoSecurityError):
        derive_auth_key(1, gen_b(), verify_prime=False)
    with pytest.raises(MTProtoSecurityError):
        derive_auth_key(DH_P - 1, gen_b(), verify_prime=False)


def test_obfuscation_header():
    init, enc, dec = make_obfuscation()
    assert len(init) == 64 and init[0] != 0xEF


def test_frame_lengths():
    assert frame(b"\x00" * 4)[0] == 1
    big = frame(b"\x00" * 4 * 200)
    assert big[0] == 0x7F and int.from_bytes(big[1:4], "little") == 200
