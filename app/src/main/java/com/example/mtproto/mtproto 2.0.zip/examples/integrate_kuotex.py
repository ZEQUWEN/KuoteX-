"""Пример подключения MTProto-канала к архитектуре KuoteX.

Показывает три точки стыковки:
  1. KeyStore        -> ваш secure storage
  2. socket_factory  -> ваш сетевой слой (тут: SOCKS5/Tor для анонимности)
  3. on_message      -> ваша шина событий / роутер апдейтов
"""
import asyncio
import logging
import os

from kuotex.mtproto import KeyStore, MTProtoChannel

logging.basicConfig(level=logging.INFO)


# --- 1. Хранилище ключей -------------------------------------------------
store = KeyStore("~/.kuotex/keys")


# --- 2. Анонимность: весь трафик через Tor (SOCKS5) ----------------------
async def tor_socket(host: str, port: int, proxy=("127.0.0.1", 9050)):
    """Минимальный SOCKS5 CONNECT. Возвращает подключённый socket."""
    r, w = await asyncio.open_connection(*proxy)
    w.write(b"\x05\x01\x00")
    await w.drain()
    assert await r.readexactly(2) == b"\x05\x00"
    h = host.encode()
    w.write(b"\x05\x01\x00\x03" + bytes([len(h)]) + h + port.to_bytes(2, "big"))
    await w.drain()
    resp = await r.readexactly(4)
    if resp[1] != 0:
        raise ConnectionError(f"SOCKS5 error {resp[1]}")
    await r.readexactly({1: 4, 3: 1, 4: 16}[resp[3]] + 2)
    sock = w.transport.get_extra_info("socket").dup()
    w.transport.abort()
    sock.setblocking(False)
    return sock


# --- 3. Шина событий KuoteX ---------------------------------------------
class EventBus:
    def __init__(self):
        self.handlers = []

    def on(self, fn):
        self.handlers.append(fn)
        return fn

    async def emit(self, payload: bytes):
        for fn in self.handlers:
            await fn(payload)


bus = EventBus()


@bus.on
async def route(payload: bytes):
    # здесь ваш TL/protobuf-декодер KuoteX
    print("<- payload", len(payload), "bytes")


async def main():
    dc_id = 2
    auth_key = store.load(dc_id)
    if auth_key is None:
        # выполнить handshake (kuotex.mtproto.handshake) и сохранить результат
        auth_key = os.urandom(256)  # ЗАГЛУШКА: только для демонстрации
        store.save(dc_id, auth_key)

    channel = MTProtoChannel(
        auth_key=auth_key,
        host="149.154.167.51",
        port=443,
        dc_id=dc_id,
        on_message=bus.emit,
        # socket_factory=lambda: tor_socket("149.154.167.51", 443),
    )
    await channel.start()
    await channel.send(b"\x00\x00\x00\x00")  # ping-заглушка
    await asyncio.sleep(2)
    await channel.close()


if __name__ == "__main__":
    asyncio.run(main())
