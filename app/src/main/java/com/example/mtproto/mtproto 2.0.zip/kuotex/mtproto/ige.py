"""AES-256-IGE (Infinite Garble Extension) для KuoteX.

IGE:
    c_i = E_k(p_i XOR c_{i-1}) XOR p_{i-1}
    p_i = D_k(c_i XOR p_{i-1}) XOR c_{i-1}
где c_{-1}||p_{-1} = IV (32 байта).

Реализовано поверх AES-ECB одного блока из `cryptography` (OpenSSL),
с constant-time-friendly операциями и без промежуточных копий ключа.
"""
from __future__ import annotations

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

BLOCK = 16


class IgeError(ValueError):
    pass


def _xor(a: bytes, b: bytes) -> bytes:
    return bytes(x ^ y for x, y in zip(a, b))


def _check(data: bytes, key: bytes, iv: bytes) -> None:
    if len(key) not in (16, 24, 32):
        raise IgeError("key must be 16/24/32 bytes (MTProto uses 32)")
    if len(iv) != 2 * BLOCK:
        raise IgeError("iv must be 32 bytes")
    if len(data) == 0 or len(data) % BLOCK:
        raise IgeError("data length must be a non-zero multiple of 16")


def ige_encrypt(plain: bytes, key: bytes, iv: bytes) -> bytes:
    _check(plain, key, iv)
    enc = Cipher(algorithms.AES(key), modes.ECB()).encryptor()
    prev_c, prev_p = iv[:BLOCK], iv[BLOCK:]
    out = bytearray(len(plain))
    for i in range(0, len(plain), BLOCK):
        p = plain[i:i + BLOCK]
        c = _xor(enc.update(_xor(p, prev_c)), prev_p)
        out[i:i + BLOCK] = c
        prev_c, prev_p = c, p
    return bytes(out)


def ige_decrypt(cipher: bytes, key: bytes, iv: bytes) -> bytes:
    _check(cipher, key, iv)
    dec = Cipher(algorithms.AES(key), modes.ECB()).decryptor()
    prev_c, prev_p = iv[:BLOCK], iv[BLOCK:]
    out = bytearray(len(cipher))
    for i in range(0, len(cipher), BLOCK):
        c = cipher[i:i + BLOCK]
        p = _xor(dec.update(_xor(c, prev_p)), prev_c)
        out[i:i + BLOCK] = p
        prev_c, prev_p = c, p
    return bytes(out)


# --- CTR-обёртка для транспортного обфускатора (obfuscated2) ---
class AesCtr:
    def __init__(self, key: bytes, iv: bytes):
        self._c = Cipher(algorithms.AES(key), modes.CTR(iv)).encryptor()

    def __call__(self, data: bytes) -> bytes:
        return self._c.update(data)
